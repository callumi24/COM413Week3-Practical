package com.example.com413week3_practical;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    public static final Random RANDOM = new Random();
    private ImageView coin;
    private TextView txtScore;
    private Button btnFlip;
    private Button btnHeads;
    private Button btnTails;
    private int prediction = -1;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        coin = (ImageView) findViewById(R.id.coin);
        btnFlip = (Button) findViewById(R.id.btnFlip);
        btnHeads = (Button) findViewById(R.id.btnHeads);
        btnTails = (Button) findViewById(R.id.btnTails);
        txtScore = (TextView) findViewById(R.id.txtScore);

        txtScore.setText("Score: " + score);

        btnFlip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flipCoin();
            }
        });

        btnHeads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prediction = 0;
            }
        });

        btnTails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prediction = 1;
            }
        });
    }

    private void flipCoin() {
        Animation fadeOut = new AlphaAnimation(1, 0);
        fadeOut.setInterpolator(new AccelerateInterpolator());
        fadeOut.setDuration(1000);
        fadeOut.setFillAfter(true);
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                float ran = RANDOM.nextFloat();
                int result = ran > 0.5f ? 1 : 0;

                coin.setImageResource(result == 1 ? R.drawable.pound_tails : R.drawable.pound_heads);

                if (prediction == result) {
                    score++;
                } else {
                    score = 0;
                }

                txtScore.setText("Score: " + score);

                Animation fadeIn = new AlphaAnimation(0, 1);
                fadeIn.setInterpolator(new DecelerateInterpolator());
                fadeIn.setDuration(1000);
                fadeIn.setFillAfter(true);

                coin.startAnimation(fadeIn);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        coin.startAnimation(fadeOut);
    }
}
